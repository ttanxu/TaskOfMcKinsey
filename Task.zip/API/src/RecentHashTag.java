import java.net.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

/**
 This class is the main class and the only class that is used to finish the first problem.
 
 @author Xu Tan
*/
public class RecentHashTag {
    /**
     @param HashTag
    */
	public static void main(String[] args) throws Exception {
		String hashTag;
		if (args.length == 1)
			hashTag = args[0];
		else {
			System.out.println("Usage: java -jar RecentHashTag.jar [HashTag]");
			return;
		}
		
		URL url = new URL("http://search.twitter.com/search.json?q=%23" + 
		hashTag + "&result_type=recent&count=100&include_entities=true");   //Using Twitter Search API
		BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
		String str = br.readLine(); // Returned Data in JSON
		br.close();

		HashSet<String> set = new HashSet<String>();
		Pattern p = Pattern.compile("[a-zA-z]+://(\\w+(-\\w+)*(\\.(\\w+(-\\w+)*))+" + "(:[0-9]{1,5})?)(/\\w+)*(\\?(\\S+=\\S+)*)?"); // Regular Expression used to match URLs
		
		JSONObject root = new JSONObject(str);  //Parsing JSON
		JSONArray results = root.getJSONArray("results");
		for (int i = 0; i < results.length(); ++i) {
			JSONObject current = results.getJSONObject(i);
			str = current.getString("text");
			if (str != null) {
				Matcher m = p.matcher(str);
				while (m.find()) {  // Matching until no URL
					if (set.add(m.group())) // Check duplication
						System.out.println(m.group());  //Print out
				}
			}
		}
	}
}
