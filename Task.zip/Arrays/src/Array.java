import java.util.*;

/**
 * Used to calculate and sort integers according to occurrences.
 * @author Xu Tan
 *
 */
public class Array {
	/**
	 * Main method to complete Task 2. Finish in O(n) time steps.
	 * @param args Integers to be counted.
	 */
	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("Usage: java -jar Array.jar [integers ...]");
			return;
		}
		
		// Used to store all numbers with specific number of occurrences so far 
		ArrayList<HashSet<Integer>> array = new ArrayList<HashSet<Integer>>(args.length > 50 ? 50 : args.length);
		// Used to store numbers and corresponding number of occurrences 
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		array.add(new HashSet<Integer>());
		for (int i = 0; i < args.length; ++i) {
			Integer num = Integer.decode(args[i]);
			if (map.containsKey(num)) {	// Occurred before, increment the number of occurrences
				array.get(map.get(num)).remove(num);
				map.put(num, map.get(num) + 1);
				if (array.size() <= map.get(num))
					array.add(new HashSet<Integer>());
				array.get(map.get(num)).add(num);
			} else {	// First occurred, set the number of occurrence to 1
				map.put(num, 0);
				array.get(0).add(num);
			}
		}
		
		for (int i = array.size() - 1; i >= 1; --i) {
			if (array.get(i).size() > 0)
				System.out.println("Occurrences " + (i + 1) + ": " + array.get(i).toString());
		}
	}
}
